Estou reenviando a tarefa pois eu havia confundido com as tarefas opcionais. 
